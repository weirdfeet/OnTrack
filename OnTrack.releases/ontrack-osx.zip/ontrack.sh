#!/bin/bash

OnTrack.app/Contents/MacOS/ontrack

